const AppIdMap = Object.freeze({
    'bot.binary.com': '1169',
    'bot.binary.me' : '15438',
    'binary.bot'    : '15481',
});
export default AppIdMap;
